#ifndef __PWM_Control_H
#define __PWM_Control_H

#include "stm32f10x.h"

void Key_Init(void);

#endif
